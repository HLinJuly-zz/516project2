
#node 2B
scp albany_ccn6@planetlab1.cs.unc.edu:./ping2B_2A.txt ./txtping/
scp albany_ccn6@planetlab1.cs.unc.edu:./trace2B_2A.txt ./txttrace/
